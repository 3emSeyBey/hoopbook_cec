<?php
$dev_data = array('id'=>'-1','firstname'=>'','lastname'=>'','username'=>'','password'=>'5da283a2d990e8d8512cf967df5bc0d0','last_login'=>'','date_updated'=>'','date_added'=>'');
if(!defined('base_url')) define('base_url','http://localhost/hoopbook/hoopbook_cec/');
if(!defined('base_app')) define('base_app', str_replace('\\','/',__DIR__).'/' );
if(!defined('DB_SERVER')) define('DB_SERVER',"sql6.freemysqlhosting.net:3306");
if(!defined('DB_USERNAME')) define('DB_USERNAME',"sql6698012");
if(!defined('DB_PASSWORD')) define('DB_PASSWORD',"RktzTYAizq");
if(!defined('DB_NAME')) define('DB_NAME',"sql6698012");
?>
